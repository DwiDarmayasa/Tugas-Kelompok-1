/** Automatically generated file. DO NOT MODIFY */
package com.uts.luassegitiga;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}